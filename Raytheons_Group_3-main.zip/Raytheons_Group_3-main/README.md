# Raytheons_Group_3
Raytheons Semester 2 group work project

Download the "Application" folder and just open it with VScode 
